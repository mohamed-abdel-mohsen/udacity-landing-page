# Landing Page  


The purpose of this project is to meet the nanodegree evaluation standard for the Front-End Web Developer.

landing page is the conversion of a static page to a page that allows some sort of interaction. 
the dynamicity is achieved throught **JavaScript**.

The landing page is to turn a static page into a page that allows for some kind of interaction,
Dynamic is achieved through **JavaScript**.




______





this project has the scope of converting a static web page into dynamic web page

we use **JavaScript** to build dynamic navbar that add a new section every time you add section in html.


when the *user* scrolling the page, it will show to him a button that can take him to top of web page.

durring the scrolling every section that in viewpoint the class active will be added to that section.

when the *user* clicking the navbar items the page will scroll smoothly to the selected section, and the selected navbar item will  highlighted the item background for the *user* to be easily following .

the web page is fully responsive to all devices screen *(large/medium/small)*.